name = "A3 Antistasi Ultimate Extender example";
author = "A3-Antistasi dev team, A3-Antistasi Ultimate dev team";
tooltip = "Antistasi Ultimate Extender example";
actionName = "GitHub";
action = "https://github.com/Westalgie/A3UExtender"
