class mapInfo {
	#include "Antistasi_Altis.Altis\mapInfo.hpp"
	#include "Antistasi_Other_Altis.Altis\mapInfo.hpp"
};