class NavGrid { //overwrite for global
    Altis = QPATHTOFOLDER(Antistasi_Altis.Altis\navGrid.sqf);
};
