allowFunctionsLog = 1;
enableDebugConsole[] = {
    "76561198296934215", // Zets/Westalgie
    "76561198219466935" // SilenceIsFatto
};
allowFunctionsRecompile = 1;
