#define MODFOLDER A3UE
#ifndef PREFIX
    #define PREFIX A3UE
#endif
