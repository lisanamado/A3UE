#define COMPONENT functions
#include "\x\A3UE\addons\core\Includes\script_mod.hpp"
