- It is NOT recommended to use these files to make a faction from scratch. Instead, take an existing entry from the main mod and replace things as needed. 

- If you are missing something or generally confused about something, only then refer to these examples!