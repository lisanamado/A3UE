class CfgMarkers 
{
	class flag_NATO;

	class my_extension_marker_aaf_remnants: flag_NATO 
	{
		name = "AAF Remnants";
		icon = QPATHTOFOLDER(Pictures\Markers\marker_aaf_torn_co.paa);
		texture = QPATHTOFOLDER(Pictures\Markers\marker_aaf_torn_co.paa);
	};
};