#define COMPONENT templates
#include "\x\A3UE\addons\core\Includes\script_mod.hpp"
