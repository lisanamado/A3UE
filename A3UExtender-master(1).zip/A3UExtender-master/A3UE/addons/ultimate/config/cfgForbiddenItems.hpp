class forbiddenItems
{
    // imports these 2 classes from the main ultimate mod
    class forbidden_unlimited_base;
    class forbidden_limited_base;

    #include "cfgForbiddenItemsMod.hpp"
};