#define COMPONENT templates
#include "\x\a3ue_blnfactions\addons\core\Includes\script_mod.hpp"
