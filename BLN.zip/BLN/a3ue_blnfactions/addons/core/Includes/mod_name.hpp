#define MODFOLDER a3ue_blnfactions
#ifndef PREFIX
    #define PREFIX a3ue_blnfactions
#endif
