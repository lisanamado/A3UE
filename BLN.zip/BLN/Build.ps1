Invoke-Expression "& '$PSScriptRoot\Tools\Builder\buildAddons.ps1'"
