PBO signing tool

==================================

	© 2013-2017 Bohemia Interactive a.s.

	All rights reserved.

	For more information see community.bistudio.com
		Check sign	https://community.bistudio.com/wiki/DSCheckSignatures
		Create key 	https://community.bistudio.com/wiki/DSCreateKey
		Sign file 	https://community.bistudio.com/wiki/DSSignFile