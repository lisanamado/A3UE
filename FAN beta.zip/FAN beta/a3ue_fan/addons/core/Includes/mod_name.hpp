#define MODFOLDER a3ue_fan
#ifndef PREFIX
    #define PREFIX a3ue_fan
#endif
