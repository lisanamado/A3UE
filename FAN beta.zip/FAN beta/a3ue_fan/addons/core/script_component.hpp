#define COMPONENT core
#include "Includes\script_mod.hpp"
