    class vehicles_base;
    #include "vehicles\vehicles_conditions.hpp"
    #include "vehicles\vehicles_includes.hpp"