#define COMPONENT functions
#include "\x\a3ue_fan\addons\core\Includes\script_mod.hpp"
