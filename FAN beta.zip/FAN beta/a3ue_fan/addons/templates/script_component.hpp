#define COMPONENT templates
#include "\x\a3ue_fan\addons\core\Includes\script_mod.hpp"
