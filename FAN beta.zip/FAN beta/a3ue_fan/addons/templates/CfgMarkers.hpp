class CfgMarkers 
{
	class flag_NATO;

	class Faction_CUP_FAN: flag_NATO 
	{
		name = "FAN"
		icon = QPATHTOFOLDER(Templates\FAN\FAN.paa);

		texture = QPATHTOFOLDER(Templates\FAN\FAN.paa);
	};
};