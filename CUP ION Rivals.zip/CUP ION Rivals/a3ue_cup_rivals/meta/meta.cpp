protocol = 1;
publishedid = -1; //ToDo add mod publisheID
