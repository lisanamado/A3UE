class CfgMarkers 
{
	class flag_NATO;

	class flag_ION: flag_NATO 
	{
		name = "ION";
		icon = QPATHTOFOLDER(Templates\IONrival\ION.paa);
		texture = QPATHTOFOLDER(PTemplates\IONrival\ION.paa);
	};
};