#define COMPONENT functions
#include "\x\a3ue_cup_rivals\addons\core\Includes\script_mod.hpp"
