        class weapons_base;

        class my_extension_weapons_vanilla : weapons_base
        {
            prefix = "my_extension_stock_vanilla"
        };