#define MAJOR 10
#define MINOR 3
#define PATCHLVL 1
#define BUILD 0