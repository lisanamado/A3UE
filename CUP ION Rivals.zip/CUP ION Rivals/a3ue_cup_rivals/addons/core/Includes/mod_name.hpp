#define MODFOLDER a3ue_cup_rivals
#ifndef PREFIX
    #define PREFIX a3ue_cup_rivals
#endif
