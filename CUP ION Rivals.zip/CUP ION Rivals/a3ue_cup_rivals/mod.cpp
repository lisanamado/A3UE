name = "A3UE CUP ION rival faction";
author = "Catertico";
tooltip = "";
actionName = "";
action = "";
